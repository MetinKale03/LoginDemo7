package com.example.logindemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name=(EditText) findViewById(R.id.txtName);
        Password=(EditText) findViewById(R.id.txtPassword);
        Info=(TextView) findViewById(R.id.txtFout);
        Login =(Button) findViewById(R.id.btnLogin);

        Info.setText("Aantal pogingen: 5");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(),Password.getText().toString());

            }
        });


    }

    private void validate(String userName, String userPassword){


        Call<LoginResult> call = RetrofitClient.getInstance().getMyApi().login(userName,userPassword);
        call.enqueue(new Callback<LoginResult>() {
            @Override
            public void onResponse(Call<LoginResult> call, Response<LoginResult> response) {
                if(response.isSuccessful()) {
                    LoginResult myheroList = response.body();
                    Log.i("LoginDemo:",myheroList.toString());
                    Toast.makeText(getApplicationContext(), myheroList.getMessage(), Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("userName",userName);
                    intent.putExtra("userPassword",userPassword);
                    intent.putExtra("loon",myheroList.getLoon());
                    startActivity(intent);
                }
                else {

                    if(response.errorBody() != null) {
                        try {
                            Toast.makeText(getApplicationContext(), response.errorBody().string(), Toast.LENGTH_LONG).show();
                            Log.i("LoginDemo:", response.errorBody().string());
                            counter--;
                            Info.setText("Aantal pogingen: "+ String.valueOf(counter));

                            if(counter==0)
                            {
                                Login.setEnabled(false);
                            }
                        } catch (IOException e) {
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                }

            }

            @Override
            public void onFailure(Call<LoginResult> call, Throwable t) {

                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
            }

        });
        /*if((userName.equals("Admin"))&&(userPassword.equals("1234")))
        {
            Intent intent=new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("userName",userName);
            intent.putExtra("userPassword",userPassword);
            startActivity(intent);
        }
        else{
            counter--;
            Info.setText("Aantal pogingen: "+ String.valueOf(counter));

            if(counter==0)
            {
                Login.setEnabled(false);
            }
        }*/
    }


}